from ultralytics import YOLO


if __name__ == '__main__':

        model = YOLO(r'/yolo-main/yolov10-sun/ultralytics/cfg/models/v10/yolov10p.yaml')
        model.train(data=r'//yolo-main/yolov12/data.yaml',  # 数据集yaml路径
                    epochs=1,  # 训练300轮
                    batch=32,  # 每一批样本的数量
                    workers=8,  # 同时32个线程
                    close_mosaic=0, #表示在训练的最后第几个轮次中禁用mosaic增强,默认10
                    val=True,
                    # close_mosaic=0,
                    # amp=False,
                    device='0',
                    # optimizer='SGD',
 #                   cache=True,
                    pretrained=False, # 预训练模型
 #                   lr0=0.02,
 #                   lrf=0.01,
                    # seed=42,
 #                   patience=50
    #                resume=True,# 中断接着训练
    #                default=True
                    )
