from ultralytics import YOLO

## 加载模型
#model = YOLO("data/yolov8.yaml")  # 从头开始构建新模型
##model = YOLO("yolov8n.pt")  # 加载预训练模型（建议用于训练）
#
## 使用模型
#model.train(data="data/s.yaml", epochs=30)  # 训练模型
#metrics = model.val()  # 在验证集上评估模型性能
#results = model("https://ultralytics.com/images/bus.jpg")  # 对图像进行预测
#success = model.export(format="onnx")  # 将模型导出为 ONNX 格式

if __name__ == '__main__':
#      model=YOLO(r'/24085404004/yolo-对比实验/yolov8(现模型)2/weights/last.pt')
#      results=model.train(resume=True)
        model = YOLO(r'/24085404004/24085404004/yolo-main/yolov10/ultralytics/cfg/models/v8/yolov8.yaml')
        model.train(data=r'/24085404004/24085404004/yolo-main/yolov12/data.yaml',  # 数据集yaml路径
                    epochs=200,  # 训练300轮
                    batch=32,  # 每一批样本的数量
                    workers=8,  # 同时32个线程
                    close_mosaic=0, #表示在训练的最后第几个轮次中禁用mosaic增强,默认10
                    # project=r'/24085404004/yolov12-train/无权重',
                    # name='yolov12_middle_4(A2C2F_SMamba+C3K2替换A2C2F)',
                    project=r'/24085404004/yolo-对比实验',
                    name='yolov8(现模型)',
                    val=True,
                    # close_mosaic=0,
                    # amp=False,
                    device='0',
                    # optimizer='SGD',
 #                   cache=True,
                    pretrained=False, # 预训练模型
 #                   lr0=0.02,
 #                   lrf=0.01,
                    # seed=42,
 #                   patience=50
    #                resume=True,# 中断接着训练
    #                default=True
                    )
#   model=YOLO(r'/24085404004/yolo-对比实验/yolov10(现模型)4/weights/last.pt')
#   results=model.train(resume=True)